<?php if(is_active_sidebar( 'home-content' ))  : ?>
    <?php dynamic_sidebar( 'home-content' )  ?>
<?php endif; ?>
                
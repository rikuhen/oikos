<!-- sliders -->
<div class="container-fluid px-0">
    <!-- <img src="images/slider_1.png" class="img-fluid" alt=""> -->
    <?php dynamic_sidebar( 'header-slider' ) ?>
</div>